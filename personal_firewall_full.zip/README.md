# Python Personal Firewall

Includes NFQUEUE firewall, packet sniffer, Tkinter GUI, and rule engine.
