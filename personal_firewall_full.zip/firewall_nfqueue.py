#!/usr/bin/env python3
import json
import hashlib
from netfilterqueue import NetfilterQueue
from scapy.all import IP, TCP, UDP
import datetime

RULES = {}

def load_rules(path="rules.json"):
    global RULES
    try:
        with open(path, "r") as f:
            RULES = json.load(f)
        print("[+] Rules loaded successfully.")
    except Exception as e:
        print("Error loading rules:", e)

def log_event(event):
    with open("firewall.log", "a") as f:
        f.write(f"{datetime.datetime.now()} - {event}\n")

def check_packet(pkt):
    scapy_pkt = IP(pkt.get_payload())

    src = scapy_pkt.src
    dst = scapy_pkt.dst
    proto = scapy_pkt.proto
    sport = scapy_pkt.sport if hasattr(scapy_pkt, "sport") else None
    dport = scapy_pkt.dport if hasattr(scapy_pkt, "dport") else None

    for rule in RULES["allow"]:
        if (rule["ip"] in [src, dst, "ANY"]) and \
           (rule["port"] in [sport, dport, "ANY"]):
            log_event(f"ALLOWED: {src}->{dst} PORT:{sport}/{dport}")
            return True

    for rule in RULES["block"]:
        if (rule["ip"] in [src, dst, "ANY"]) and \
           (rule["port"] in [sport, dport, "ANY"]):
            log_event(f"BLOCKED: {src}->{dst} PORT:{sport}/{dport}")
            return False

    return True

def process_packet(pkt):
    try:
        allowed = check_packet(pkt)
        pkt.accept() if allowed else pkt.drop()
    except Exception as e:
        print("Error processing packet:", e)
        pkt.accept()

if __name__ == "__main__":
    load_rules("rules.json")
    nfq = NetfilterQueue()
    nfq.bind(1, process_packet)
    print("[+] Firewall running...")
    try:
        nfq.run()
    except KeyboardInterrupt:
        print("\n[!] Stopping firewall.")
