# Full Project Report
Complete technical explanation of Personal Firewall using Python.
