import json
import hashlib
import tkinter as tk
from tkinter import messagebox, simpledialog, scrolledtext

CONFIG_FILE = "config.json"

def load_config():
    try:
        with open(CONFIG_FILE, "r") as f:
            return json.load(f)
    except:
        return {"password_hash": ""}

def save_config(cfg):
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=4)

def hash_password(pwd):
    return hashlib.sha256(pwd.encode()).hexdigest()

def authenticate():
    cfg = load_config()
    if cfg["password_hash"] == "":
        return True
    pwd = simpledialog.askstring("Password", "Enter firewall password:", show="*")
    return hash_password(pwd) == cfg["password_hash"]

def set_password():
    pwd = simpledialog.askstring("Password", "Set new password:", show="*")
    if pwd:
        cfg = load_config()
        cfg["password_hash"] = hash_password(pwd)
        save_config(cfg)
        messagebox.showinfo("OK", "Password updated.")

def load_logs(textbox):
    try:
        with open("firewall.log", "r") as f:
            textbox.delete(1.0, tk.END)
            textbox.insert(tk.END, f.read())
    except:
        textbox.insert(tk.END, "No logs yet.")

app = tk.Tk()
app.title("Python Personal Firewall")

if not authenticate():
    messagebox.showerror("Error", "Incorrect password!")
    app.destroy()

log_box = scrolledtext.ScrolledText(app, width=80, height=25)
log_box.pack()

btn_refresh = tk.Button(app, text="Refresh Logs", command=lambda: load_logs(log_box))
btn_refresh.pack(pady=5)

btn_pass = tk.Button(app, text="Set/Change Password", command=set_password)
btn_pass.pack(pady=5)

load_logs(log_box)

app.mainloop()
