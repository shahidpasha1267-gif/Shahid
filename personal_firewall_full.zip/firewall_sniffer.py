#!/usr/bin/env python3
import json
import datetime
from scapy.all import sniff, IP

RULES = {}

def load_rules(path="rules.json"):
    global RULES
    try:
        with open(path, "r") as f:
            RULES = json.load(f)
        print("[+] Rules loaded for sniffer.")
    except Exception as e:
        print("Error loading rules:", e)

def log_event(event):
    with open("firewall.log", "a") as f:
        f.write(f"{datetime.datetime.now()} - {event}\n")

def packet_callback(pkt):
    if IP in pkt:
        src = pkt[IP].src
        dst = pkt[IP].dst
        sport = pkt.sport if hasattr(pkt, "sport") else None
        dport = pkt.dport if hasattr(pkt, "dport") else None
        log_event(f"SNIFFED: {src}->{dst} PORT:{sport}/{dport}")

if __name__ == "__main__":
    load_rules("rules.json")
    print("[+] Sniffer running...")
    sniff(filter="ip", prn=packet_callback, store=False)
